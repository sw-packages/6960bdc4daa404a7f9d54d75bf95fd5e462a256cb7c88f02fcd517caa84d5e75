//
// Guards.h
//


#ifndef Poco_CppUnit_Guards_INCLUDED
#define Poco_CppUnit_Guards_INCLUDED

#include "CppUnit/Guards.h"

#endif // Poco_CppUnit_Guards_INCLUDED
