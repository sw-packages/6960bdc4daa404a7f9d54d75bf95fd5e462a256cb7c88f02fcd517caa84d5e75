//
// TextTestResult.h
//


#ifndef Poco_CppUnit_TextTestResult_INCLUDED
#define Poco_CppUnit_TextTestResult_INCLUDED

#include "CppUnit/TextTestResult.h"

#endif // Poco_CppUnit_TextTestResult_INCLUDED
