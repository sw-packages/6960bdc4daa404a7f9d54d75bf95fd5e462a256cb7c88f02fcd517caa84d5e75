//
// TestCase.h
//


#ifndef Poco_CppUnit_TestCase_INCLUDED
#define Poco_CppUnit_TestCase_INCLUDED

#include "CppUnit/TestCase.h"

#endif // Poco_CppUnit_TestCase_INCLUDED
